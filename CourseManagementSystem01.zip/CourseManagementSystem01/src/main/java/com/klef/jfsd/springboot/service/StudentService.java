package com.klef.jfsd.springboot.service;

import java.util.List;

import com.klef.jfsd.springboot.models.Course;
import com.klef.jfsd.springboot.models.Student;

public interface StudentService 
{
	public Student addstudent(Student student);
	public Student checkstudentlogin(String uname,String pwd);
	public Student viewstudent(String uname);
	public Course viewcoursebyid(int id);
	public List<Course> viewcoursesforstudent();
	public Student studentprofile(String euname);
}
