package com.klef.jfsd.springboot.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.klef.jfsd.springboot.models.Admin;
import com.klef.jfsd.springboot.models.Course;
import com.klef.jfsd.springboot.models.Faculty;
import com.klef.jfsd.springboot.models.Student;
import com.klef.jfsd.springboot.service.AdminService;
import com.klef.jfsd.springboot.service.FacultyService;
import com.klef.jfsd.springboot.service.StudentService;

@Controller
public class ClientController
{
	@Autowired
	
	private AdminService adminService;
	
	@Autowired
	private FacultyService facultyService;
	
	@Autowired
	private StudentService studentService;
	
	@GetMapping("/")
	public String mainhomedemo()
	{
		return "index";
	}
	
	@GetMapping("/studentlogin")
	public ModelAndView studentlogindemo()
	{
		ModelAndView mv = new ModelAndView("studentlogin");
		
		return mv;
	}
	
	@GetMapping("/adminlogin")
	public ModelAndView adminlogindemo()
	{
		ModelAndView mv = new ModelAndView("adminlogin");
		
		return mv;
	}
	
	@GetMapping("/facultylogin")
	public ModelAndView facultylogindemo()
	{
		ModelAndView mv = new ModelAndView("facultylogin");
		
		return mv;
	}
	
	@GetMapping("/facultyregistration")
	public ModelAndView facultyregdemo()
	{
		ModelAndView mv = new ModelAndView("facultyregistration", "emp",new Faculty());
		return mv;
	}
	
	@GetMapping("/studentregistration")
	public ModelAndView studentregdemo()
	{
		ModelAndView mv = new ModelAndView("studentregistration", "emp",new Student());
		return mv;
	}
	
	@GetMapping("/addcourse")
	public ModelAndView courseregdemo()
	{
		ModelAndView mv = new ModelAndView("addcourse", "course", new Course());
		return mv;
	}
		
	@GetMapping("/adminhome")
	public ModelAndView adminhomedemo()
	{
		ModelAndView mv = new ModelAndView("adminhome");
		
		return mv;
	}
	
	@GetMapping("/addfaculty")
	public ModelAndView facultyrgdemo()
	{
		ModelAndView mv=new ModelAndView("facultyregistration","emp",new Faculty());
		return mv;
	}
	@GetMapping("/facultyhome")
	public ModelAndView facultyhomedemo(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView("facultyhome");
		
		HttpSession session = request.getSession();
		
		String euname = (String) session.getAttribute("euname");
		
		mv.addObject("euname", euname);
		
		return mv;
	}
	
	@GetMapping("/studenthome")
	public ModelAndView studenthomedemo(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView("studenthome");
		
		HttpSession session = request.getSession();
		
		String euname = (String) session.getAttribute("euname");
		
		mv.addObject("euname", euname);
		
		return mv;
	}
		
	@GetMapping("/viewallfaculty")
	public ModelAndView viewallfacultydemo()
	{
		ModelAndView mv = new ModelAndView("viewallfaculty");
		
		List<Faculty> faclist = adminService.viewallfaculty();
		mv.addObject("faclist",faclist);
		
		return mv;
	}
	
	@GetMapping("/viewallstudents")
	public ModelAndView viewallstudentsdemo()
	{
		ModelAndView mv = new ModelAndView("viewallstudents");
		
		List<Student> faclist = adminService.viewallstudents();
		mv.addObject("faclist",faclist);
		
		return mv;
	}
	
	@GetMapping("/viewallcourses")
	public ModelAndView viewallcoursesdemo()
	{
		ModelAndView mv = new ModelAndView("viewallcourses");
		
		List<Course> courselist = adminService.viewallcourses();
		mv.addObject("courselist",courselist);
		
		return mv;
	}
	
	@GetMapping("/viewcoursesforstudent")
	public ModelAndView viewallcoursesforstudentdemo()
	{
		ModelAndView mv = new ModelAndView("viewcoursesforstudent");
		
		List<Course> courselist = studentService.viewcoursesforstudent();
		mv.addObject("courselist",courselist);
		
		return mv;
	}
	
	
	@PostMapping("/checkadminlogin")
	public ModelAndView checkadminlogindemo(HttpServletRequest request)
	{
		ModelAndView mv =  new ModelAndView();
		
		String auname = request.getParameter("auname");
		String apwd = request.getParameter("apwd");
		
		Admin admin = adminService.checkadminlogin(auname, apwd);
		
		if(admin!=null)
		{
			
			HttpSession session = request.getSession();
			
			session.setAttribute("auname", auname);
			
			mv.setViewName("adminhome");
		}
		else
		{
			mv.setViewName("adminlogin");
			mv.addObject("msg", "Login Failed");
		}
		
		
		return mv;
	}
	
	
	@PostMapping("/checkfacultylogin")
	public ModelAndView checkfacultylogindemo(HttpServletRequest request)
	{
		ModelAndView mv =  new ModelAndView();
		
		String euname = request.getParameter("euname");
		String epwd = request.getParameter("epwd");
		
		Faculty emp = facultyService.checkfacultylogin(euname, epwd);
		
		if(emp!=null)
		{
			HttpSession session = request.getSession();
			
			session.setAttribute("euname", euname);
			
			mv.setViewName("facultyhome");
		}
		else
		{
			mv.setViewName("facultylogin");
			mv.addObject("msg", "Login Failed");
		}
		
		
		return mv;
	}
	
	@PostMapping("/checkstudentlogin")
	public ModelAndView checkstudentlogindemo(HttpServletRequest request)
	{
		ModelAndView mv =  new ModelAndView();
		
		String euname = request.getParameter("euname");
		String epwd = request.getParameter("epwd");
		
		Student emp = studentService.checkstudentlogin(euname, epwd);
		
		if(emp!=null)
		{
			HttpSession session = request.getSession();
			
			session.setAttribute("euname", euname);
			
			mv.setViewName("studenthome");
		}
		else
		{
			mv.setViewName("studentlogin");
			mv.addObject("msg", "Login Failed");
		}
		
		
		return mv;
	}
	
	
	@PostMapping("/addstudent")
	public String addstudentdemo(@ModelAttribute("emp") Student student)
	{
		studentService.addstudent(student);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("studentregistration");
	    mv.addObject("msg", "student Registered Successfully");
		return "redirect:adminhome";
	}
	@PostMapping("/addfaculty")
	public String addfacultydemo(@ModelAttribute("emp") Faculty faculty)
	{
		facultyService.addfaculty(faculty);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("facultyregistration");
	    mv.addObject("msg", "faculty Registered Successfully");
		return "redirect:adminhome";
	}
	
	@PostMapping("/addcourse")
	public String addcoursedemo(@ModelAttribute("course") Course course)
	{
		adminService.addcourse(course);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("addcourse");
	    mv.addObject("msg", "course inserted Successfully");
		return "redirect:adminhome";
	}
	
	@GetMapping("/deletefaculty")
	public String deletefacultydemo(@RequestParam("id") int eid)
	{
		adminService.deletefaculty(eid);
		
		return "redirect:viewallfaculty";
	}
	
	@GetMapping("/deletecourse")
	public String deletecoursedemo(@RequestParam("id") int eid)
	{
		adminService.deletecourse(eid);
		
		return "redirect:viewallcourses";
	}
	
	@GetMapping("/deletestudent")
	public String deletestudentdemo(@RequestParam("id") int eid)
	{
		adminService.deletestudent(eid);
		
		return "redirect:viewallstudents";
	}
	
	@GetMapping("/viewfaculty")
	public ModelAndView viewfaculty(HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		
		String euname = (String) session.getAttribute("euname");
		
		Faculty emp =  facultyService.viewfaculty(euname);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("viewfaculty");
		mv.addObject("emp",emp);
		
		return mv;
	}
	
	@GetMapping("/viewstudent")
	public ModelAndView viewstudent(HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		
		String euname = (String) session.getAttribute("euname");
		
		Student emp =  studentService.viewstudent(euname);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("viewstudent");
		mv.addObject("emp",emp);
		
		return mv;
	}
	
	@GetMapping("/studentprofile")
	public ModelAndView studentprofile(HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		
		String euname = (String) session.getAttribute("euname");
		
		Student emp =  studentService.studentprofile(euname);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("studentprofile");
		mv.addObject("emp",emp);
		
		return mv;
	}
		
	@GetMapping("/facultychangepwd")
	public ModelAndView echangepwd(HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		
		String euname = (String) session.getAttribute("euname");
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("facultychangepwd");
		mv.addObject("euname",euname);
		
		return mv;
	}
	
	@PostMapping("/facultychangepwd")
	public ModelAndView updatefacultypwddemo(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("facultychangepwd");
		
		HttpSession session = request.getSession();
		
		String euname = (String) session.getAttribute("euname");
		
		String eoldpwd = request.getParameter("eopwd");
		String enewpwd = request.getParameter("enpwd");
		
		int n = facultyService.changefacultypassword(eoldpwd, enewpwd, euname);
		
		if(n > 0)
		{
			
			mv.addObject("msg","Password Updated Successfully");
		}
		else
		{
			mv.addObject("msg","Old Password is Incorrect");
		}
		
		return mv;
	}
	
	@GetMapping("/viewfacultybyid")
	public ModelAndView viewfacultybyiddemo(@RequestParam("id") int fid)
	{
		Faculty fac = adminService.viewfacultybyid(fid);
		
		ModelAndView mv = new ModelAndView();
		
		mv.setViewName("viewfacultybyid");
		mv.addObject("faculty",fac);
		
		return mv;
	}
	
	@GetMapping("/viewstudentbyid")
	public ModelAndView viewstudentbyiddemo(@RequestParam("id") int fid)
	{
		Student s = adminService.viewstudentbyid(fid);
		
		ModelAndView mv = new ModelAndView();
		
		mv.setViewName("viewstudentbyid");
		mv.addObject("student",s);
		
		return mv;
	}
	
	@GetMapping("/viewcoursebyid")
	public ModelAndView viewcoursebyiddemo(@RequestParam("id") int fid)
	{
		Course c = adminService.viewcoursebyid(fid);
		
		ModelAndView mv = new ModelAndView();
		
		mv.setViewName("viewcoursebyid");
		mv.addObject("course",c);
		
		return mv;
	}
	
}
