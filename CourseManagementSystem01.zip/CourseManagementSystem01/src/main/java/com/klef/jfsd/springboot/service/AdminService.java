package com.klef.jfsd.springboot.service;

import java.util.List;

import com.klef.jfsd.springboot.models.Admin;
import com.klef.jfsd.springboot.models.Course;
import com.klef.jfsd.springboot.models.Faculty;
import com.klef.jfsd.springboot.models.Student;



public interface AdminService 

{
	public Admin checkadminlogin(String uname,String pwd);
	public List<Faculty> viewallfaculty();
	public void deletefaculty(int id);
	public Faculty viewfacultybyid(int id);
	
	public List<Student> viewallstudents();
	public void deletestudent(int id);
	public Student viewstudentbyid(int id);
	
	public Course addcourse(Course course);
	public void deletecourse(int id);
	public Course viewcoursebyid(int id);
	public List<Course> viewallcourses();
	
	
	
}
