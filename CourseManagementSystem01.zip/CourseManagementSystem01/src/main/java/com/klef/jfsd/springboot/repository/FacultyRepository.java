package com.klef.jfsd.springboot.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.klef.jfsd.springboot.models.Faculty;


@Repository
public interface FacultyRepository extends CrudRepository<Faculty, Integer>
{
	@Query("select e from Faculty e where username=?1 and password=?2")
	public Faculty checkfacultylogin(String uname,String pwd);
	
	@Query("select e from Faculty e where username=?1")
	public Faculty viewfaculty(String uname);
	
	@Transactional
	@Modifying
	@Query("update Faculty e set e.password=?1 where e.password=?2 and e.username=?3")
	public int updatefacultypassword(String empnewpwd,String empoldpwd,String empuname);
}
