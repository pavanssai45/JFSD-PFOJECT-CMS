package com.klef.jfsd.springboot.repository;

import org.springframework.data.repository.CrudRepository;

import com.klef.jfsd.springboot.models.Course;
import com.klef.jfsd.springboot.models.Faculty;

public interface CourseRepository extends CrudRepository<Course, Integer>
{
	
}
