package com.klef.jfsd.springboot.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.klef.jfsd.springboot.models.Student;

@Repository
public interface StudentRepository extends CrudRepository<Student, Integer>
{
	@Query("select e from Student e where username=?1 and password=?2")
	public Student checkstudentlogin(String uname,String pwd);
	
	@Query("select e from Student e where username=?1")
	public Student viewstudent(String uname);
	
	@Transactional
	@Modifying
	@Query("update Student e set e.password=?1 where e.password=?2 and e.username=?3")
	public int updateStudentpassword(String empnewpwd,String empoldpwd,String empuname);
    
	@Query("select e from Student e where username=?1")
	public Student studentprofile(String euname);
	
	
}
