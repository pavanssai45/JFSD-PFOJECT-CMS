package com.klef.jfsd.springboot.service;

import java.util.List;

import com.klef.jfsd.springboot.models.Course;
import com.klef.jfsd.springboot.models.Faculty;

public interface FacultyService
{
	public Faculty addfaculty(Faculty employee);
	public Faculty checkfacultylogin(String uname,String pwd);
	public Faculty viewfaculty(String uname);
	public int changefacultypassword(String empoldpwd,String empnewpwd,String euname);
	public List<Course> viewmycourses(int id);
	
}

