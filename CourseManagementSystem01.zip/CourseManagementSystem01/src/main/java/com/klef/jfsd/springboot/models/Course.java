package com.klef.jfsd.springboot.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Course_table")
public class Course 
{
   @Id
   @GeneratedValue
   private int courseid;
   @Column(nullable = false)
   private int coursecredits;
   @Column(nullable = false,length = 200)
   private String coursename;
   @Column(nullable = false,unique=true,length = 10)
   private String coursecode;
   @Column(nullable = false,length = 200)
   private String semister;
   @Column(nullable = false,length = 20)
   private String ccid;
   @Column(nullable = false,length = 200)
   private String department;
   @Column(nullable = false,length = 200)
   private int year;
   @Column(nullable = false,length = 200)
   private String batch;
   @Column(nullable = false,length = 200)
   private String ltps;
@Override
public String toString() {
	return "Course [courseid=" + courseid + ", coursecredits=" + coursecredits + ", coursename=" + coursename
			+ ", coursecode=" + coursecode + ", semister=" + semister + ", ccid=" + ccid + ", department=" + department
			+ ", year=" + year + ", batch=" + batch + ", ltps=" + ltps + "]";
}
public int getCourseid() {
	return courseid;
}
public void setCourseid(int courseid) {
	this.courseid = courseid;
}
public int getCoursecredits() {
	return coursecredits;
}
public void setCoursecredits(int coursecredits) {
	this.coursecredits = coursecredits;
}
public String getCoursename() {
	return coursename;
}
public void setCoursename(String coursename) {
	this.coursename = coursename;
}
public String getCoursecode() {
	return coursecode;
}
public void setCoursecode(String coursecode) {
	this.coursecode = coursecode;
}
public String getSemister() {
	return semister;
}
public void setSemister(String semister) {
	this.semister = semister;
}
public String getCcid() {
	return ccid;
}
public void setCcid(String ccid) {
	this.ccid = ccid;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}
public int getYear() {
	return year;
}
public void setYear(int year) {
	this.year = year;
}
public String getBatch() {
	return batch;
}
public void setBatch(String batch) {
	this.batch = batch;
}
public String getLtps() {
	return ltps;
}
public void setLtps(String ltps) {
	this.ltps = ltps;
}

}

