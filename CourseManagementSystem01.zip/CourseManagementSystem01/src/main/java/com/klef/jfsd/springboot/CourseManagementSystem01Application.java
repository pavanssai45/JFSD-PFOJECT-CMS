package com.klef.jfsd.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseManagementSystem01Application {

	public static void main(String[] args) {
		SpringApplication.run(CourseManagementSystem01Application.class, args);
		System.out.println("run avtundhi myaaann....");
	}

}
